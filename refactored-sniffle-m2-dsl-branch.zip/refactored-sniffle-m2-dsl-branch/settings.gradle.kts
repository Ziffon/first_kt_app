rootProject.name = "first_kt_app"
include("m2-dsl")
